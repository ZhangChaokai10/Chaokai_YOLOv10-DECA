from ultralytics import YOLO
import os
path = 'yolov10n-DECA.yaml'
model = YOLO(path).load('yolov10n.pt')
# # 冻结骨干网络
# def freeze_layer(trainer):
#     model = trainer.model
#     num_freeze = 10  # Adjust as necessary
#     freeze = [f'model.{x}.' for x in range(num_freeze)]
#     for name, param in model.named_parameters():
#         if any(layer in name for layer in freeze):
#             param.requires_grad = False
#             print(f'Freezing {name}')

# model.add_callback("on_train_start", freeze_layer)


model.train(data="datasets_road.yaml",epochs=300,batch=32,imgsz=640,plots=True)