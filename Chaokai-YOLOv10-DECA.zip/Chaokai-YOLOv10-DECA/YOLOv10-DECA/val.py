from ultralytics import YOLO
# Load a model
model = YOLO("./runs/detect/yolov10n-DECA/weights/best.pt")
# Validate with a custom dataset
validation_results = model.val(data="datasets_crack.yaml", imgsz=640, conf=0.25, iou=0.6, device="0",save_json=True)