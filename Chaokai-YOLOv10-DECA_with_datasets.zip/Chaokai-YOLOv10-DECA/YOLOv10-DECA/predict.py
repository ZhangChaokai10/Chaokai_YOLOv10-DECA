from ultralytics import YOLO

# Load YOLOv10 model
model = YOLO("./runs/detect/yolov10n-DECA/weights/best.pt")

# Define path 
source = "/home/featurize/data/datasets_crack/images/val"

# Run inference on the source
results = model.predict(source, save=True)  # generator of Results objects