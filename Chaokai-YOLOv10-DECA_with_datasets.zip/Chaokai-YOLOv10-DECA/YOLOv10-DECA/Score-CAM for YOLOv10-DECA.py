import cv2
import numpy as np
import torch
from ultralytics import YOLO
import os
from tqdm import tqdm


def score_cam(model, img_tensor, target_layer):
    feature_maps = []

    def hook_fn(module, input, output):
        feature_maps.append(output)

    handle = target_layer.register_forward_hook(hook_fn)

    with torch.no_grad():
        output = model(img_tensor)

    handle.remove()

    if not feature_maps:
        print("No feature maps captured. Check if the target layer is correct.")
        return np.zeros((640, 640))

    # 处理钩子函数可能返回复杂结构的情况
    feature_maps = feature_maps[0]
    if isinstance(feature_maps, (tuple, list)):
        print(f"Feature maps is a {type(feature_maps)} with {len(feature_maps)} elements")
        # 尝试找到一个合适的张量
        for item in feature_maps:
            if isinstance(item, torch.Tensor):
                feature_maps = item
                break
        else:
            print("Unable to find a tensor in feature maps")
            return np.zeros((640, 640))

    print(f"Feature maps shape: {feature_maps.shape}")

    # 确保 feature_maps 是 4D 张量 [batch, channels, height, width]
    if len(feature_maps.shape) == 3:
        feature_maps = feature_maps.unsqueeze(0)
    elif len(feature_maps.shape) == 2:
        feature_maps = feature_maps.unsqueeze(0).unsqueeze(0)

    b, k, u, v = feature_maps.shape

    upsampled = torch.nn.functional.interpolate(feature_maps, size=(640, 640), mode='bilinear', align_corners=False)
    normalized = (upsampled - upsampled.min()) / (upsampled.max() - upsampled.min() + 1e-10)

    scores = []
    for i in range(k):
        masked_input = img_tensor * normalized[:, i:i + 1]
        with torch.no_grad():
            output = model(masked_input)

        # 适应YOLO输出格式
        if isinstance(output, list) and len(output) > 0:
            if hasattr(output[0], 'boxes'):
                score = output[0].boxes.conf.max() if len(output[0].boxes) > 0 else 0
            elif isinstance(output[0], torch.Tensor):
                score = output[0].max().item()
            else:
                print(f"Unexpected output format: {type(output[0])}")
                score = 0
        else:
            print(f"Unexpected output format: {type(output)}")
            score = 0
        scores.append(score)

    weights = torch.tensor(scores).view(1, -1, 1, 1)
    cam = (weights * normalized).sum(1)
    cam = torch.relu(cam)
    cam = cam - cam.min()
    cam = cam / (cam.max() + 1e-7)

    return cam[0].cpu().numpy()


# process_image 和 main 函数

def process_image(model, img_path, target_layer, output_path):
    try:
        img = cv2.imread(img_path)
        if img is None:
            print(f"Unable to read image: {img_path}")
            return False

        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_resized = cv2.resize(img, (640, 640))
        img_tensor = torch.from_numpy(img_resized.transpose(2, 0, 1)).float().unsqueeze(0) / 255.0

        print(f"Input tensor shape: {img_tensor.shape}")

        cam = score_cam(model, img_tensor, target_layer)

        cam = cv2.resize(cam, (img.shape[1], img.shape[0]))

        heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
        output = cv2.addWeighted(img, 0.8, heatmap, 0.4, 0)

        cv2.imwrite(output_path, cv2.cvtColor(output, cv2.COLOR_RGB2BGR))
        return True
    except Exception as e:
        print(f"Error processing image {img_path}: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    model_path = r'C:\Users\DELL\Desktop\crack detection\results\detect\yolov10-DECA\weights\best.pt'
    input_folder = r'F:\data\datasets_crack\images\val'
    output_folder = r'F:\data\datasets_crack\images\Score-CAM_YOLOv10-DECA'

    os.makedirs(output_folder, exist_ok=True)

    model = YOLO(model_path)
    target_layer = model.model.model[-2]

    image_files = [f for f in os.listdir(input_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    successful_count = 0
    for image_file in tqdm(image_files, desc="Processing images"):
        input_path = os.path.join(input_folder, image_file)
        output_path = os.path.join(output_folder, f"scorecam_{image_file}")
        if process_image(model, input_path, target_layer, output_path):
            successful_count += 1

    print(
        f"Successfully processed {successful_count} out of {len(image_files)} images. Results saved in {output_folder}")


if __name__ == "__main__":
    main()
