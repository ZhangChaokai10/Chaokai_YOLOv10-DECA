Creating by ZhangChaokai
Email:1152619727@qq.com
The YOLOv10-DECA.yaml and YOLOv10-ECA.yaml are in YOLOv10-DECA.
The DynamicECA module is in ultralytics\nn\modules\attention.py